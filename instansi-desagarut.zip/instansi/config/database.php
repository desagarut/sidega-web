<?php

$db['default']['hostname'] = 'localhost';
$db['default']['username'] = 'kadm3665_m4h1num';
$db['default']['password'] = 'Murot4l.KOPIhit4m.';
$db['default']['database'] = 'kadm3665_M41n_web';

$db['default']['stricton'] = TRUE;
?>